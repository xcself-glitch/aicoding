#!/usr/bin/env python3
"""
兆易创新持仓监控 - 轻量版
使用腾讯财经接口，触发预警时即时通知
"""
import requests
import json
import time
from datetime import datetime

# 配置
STOCK_CONFIG = {
    "code": "603986",
    "name": "兆易创新",
    "market": "sh",
    "cost": 298.69,
    "shares": 1100,
}

# 预警阈值 (统一使用正数表示阈值大小)
ALERTS = {
    "cost_pct_above": 10.0,      # 盈利10%提醒
    "cost_pct_below": 10.0,      # 亏损扩大至10%提醒
    "target_buy": 270.0,         # 补仓点
    "target_reduce": 295.0,      # 减仓点
    "stop_loss": 265.0,          # 止损价
    "change_pct_above": 4.0,     # 日内大涨4%
    "change_pct_below": 4.0,     # 日内大跌4%
}

def fetch_tencent_quote(code):
    """获取腾讯财经实时行情"""
    try:
        prefix = 'sh' if code.startswith('6') else 'sz'
        url = f"http://qt.gtimg.cn/q={prefix}{code}"
        resp = requests.get(url, timeout=5)
        resp.encoding = 'gbk'
        
        text = resp.text
        start = text.find('"') + 1
        end = text.rfind('"')
        parts = text[start:end].split('~')
        
        # 腾讯字段映射 (0-based index)
        # parts[1]=名称, [3]=现价, [4]=昨收, [5]=今开
        # [33]=最高, [34]=最低, [31]=涨跌额, [32]=涨跌幅%
        # [36]=成交量, [49]=量比
        return {
            'name': parts[1],
            'price': float(parts[3]),
            'prev_close': float(parts[4]),
            'open': float(parts[5]),
            'high': float(parts[33]),
            'low': float(parts[34]),
            'change': float(parts[31]),      # 涨跌额
            'change_pct': float(parts[32]),  # 涨跌幅%
            'volume': int(parts[36]),
            'volume_ratio': float(parts[49]) if parts[49] else 1.0,
        }
    except Exception as e:
        print(f"获取数据失败: {e}")
        return None

def check_alerts(data, config, alerts):
    """检查预警条件"""
    triggered = []
    price = data['price']
    cost = config['cost']
    change_pct = data['change_pct']
    cost_change_pct = (price - cost) / cost * 100
    
    # 1. 成本百分比预警
    if alerts.get('cost_pct_above') and cost_change_pct >= alerts['cost_pct_above']:
        triggered.append({
            'level': 'warning',
            'type': '盈利达标',
            'message': f"盈利 {cost_change_pct:.1f}% (目标 {alerts['cost_pct_above']}%)",
            'action': '可考虑减仓或继续持有'
        })
    
    if alerts.get('cost_pct_below') and cost_change_pct <= -alerts['cost_pct_below']:
        triggered.append({
            'level': 'warning',
            'type': '亏损扩大',
            'message': f"亏损扩大至 {abs(cost_change_pct):.1f}% (阈值 -{alerts['cost_pct_below']}%)",
            'action': '关注支撑位，考虑补仓或止损'
        })
    
    # 2. 目标买卖点
    if alerts.get('target_buy') and price <= alerts['target_buy']:
        triggered.append({
            'level': 'warning',
            'type': '买入信号',
            'message': f"股价 ¥{price:.2f} 触及补仓点 ¥{alerts['target_buy']}",
            'action': '支撑位附近，可考虑分批补仓'
        })
    
    if alerts.get('target_reduce') and price >= alerts['target_reduce']:
        triggered.append({
            'level': 'caution',
            'type': '减仓信号',
            'message': f"股价 ¥{price:.2f} 接近成本线 ¥{config['cost']}",
            'action': '接近回本，可考虑减仓锁定风险'
        })
    
    if alerts.get('stop_loss') and price <= alerts['stop_loss']:
        triggered.append({
            'level': 'warning',
            'type': '止损信号',
            'message': f"股价 ¥{price:.2f} 跌破止损价 ¥{alerts['stop_loss']}",
            'action': '趋势转弱，建议止损离场'
        })
    
    # 3. 日内异动 (阈值在配置中是正数，需要判断正负)
    if alerts.get('change_pct_above') and change_pct >= alerts['change_pct_above']:
        triggered.append({
            'level': 'caution',
            'type': '大涨提醒',
            'message': f"日内大涨 {change_pct:.1f}%",
            'action': '关注量能，可能是突破信号'
        })
    
    if alerts.get('change_pct_below') and change_pct <= -alerts['change_pct_below']:
        triggered.append({
            'level': 'caution',
            'type': '大跌提醒',
            'message': f"日内大跌 {change_pct:.1f}%",
            'action': '关注支撑，可能是恐慌盘'
        })
    
    return triggered

def format_output(data, config, alerts):
    """格式化输出"""
    price = data['price']
    cost = config['cost']
    shares = config['shares']
    cost_change_pct = (price - cost) / cost * 100
    profit = (price - cost) * shares
    
    lines = [
        "=" * 60,
        f"🔍 兆易创新 ({config['code']}) 监控报告",
        "=" * 60,
        f"📊 持仓: {shares}股 | 成本: ¥{cost:.2f}",
        f"💰 现价: ¥{price:.2f} ({data['change_pct']:+.2f}%)",
        f"📈 盈亏: {'🔴' if profit >= 0 else '🟢'}¥{profit:+,.0f} ({cost_change_pct:+.2f}%)",
        f"📉 区间: ¥{data['low']:.2f} - ¥{data['high']:.2f}",
        f"📊 量比: {data['volume_ratio']:.2f}",
    ]
    
    if alerts:
        lines.append("")
        lines.append(f"⚠️  触发 {len(alerts)} 条预警:")
        for alert in alerts:
            icon = "🚨" if alert['level'] == 'warning' else "⚠️"
            lines.append(f"   {icon} [{alert['type']}] {alert['message']}")
            lines.append(f"      💡 建议: {alert['action']}")
    else:
        lines.append("")
        lines.append("✅ 当前无预警，持仓正常")
    
    lines.append("=" * 60)
    return "\n".join(lines)

def main():
    print(f"[{datetime.now().strftime('%Y-%m-%d %H:%M:%S')}] 启动兆易创新监控...")
    
    # 获取数据
    data = fetch_tencent_quote(STOCK_CONFIG['code'])
    if not data:
        print("❌ 获取行情失败")
        return
    
    # 检查预警
    alerts = check_alerts(data, STOCK_CONFIG, ALERTS)
    
    # 输出报告
    print(format_output(data, STOCK_CONFIG, alerts))
    
    # 返回预警数量（用于脚本判断）
    return len(alerts)

if __name__ == "__main__":
    alert_count = main()
    exit(alert_count)  # 有预警时返回非0
